Game.ExecutableName = "halo.exe"; // Replace with exact game .exe
Game.GUID = "HaloArenaEvolved";
Game.GameName = "Halo CE: Arena Evolved";
Game.Description = "IMPORTANT: Once all game windows finish opening and resizing, press the END key to lock inputs so each controller only controls its assigned screen. Press END again to unlock when finished.";
Game.MaxPlayers = 16;
Game.MaxPlayersOneMonitor = 16;
Game.PlayersPerInstance = 4;

// File & Environment Isolation
Game.SymlinkGame = true;
Game.UseNucleusEnvironment = true;
Game.FakeFocus = true;
Game.HookFocus = true;

// Window Management (Removes borders & forces custom split-screen sizes)
Game.SetWindowHook = true;
Game.ResetWindows = true;
Game.Hook.ForceFocus = true;
Game.Hook.ForceFocusWindowName = "Halo"; // Match the title bar text of the game window

// Controller Isolation (Routes 1 controller per instance & bypasses 4-pad limits)
Game.SupportsMultipleKeyboardsAndMice = true
Game.LockInputToggleKey = 0x23;
Game.Hook.DInputEnabled = true;
Game.Hook.XInputEnabled = true;
Game.Hook.XInputReroute = true;
Game.XInputPlusDll = ["xinput1_3.dll", "xinput1_4.dll", "xinput9_1_0.dll"];

// Uncomment and add the Mutex name from Process Explorer if the game blocks 2nd instances:
// Game.KillMutex = ["HaloMutexNameHere"];

Game.Play = function() {
  // Forces each instance to launch at its assigned split-screen resolution
  
  var Args = (Context.Args = " -window -width " + Context.Width + " -height " + Context.Height);
  Context.StartArguments = Args;
};